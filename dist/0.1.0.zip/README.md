Extension Framework
===================
Build once. Build twice. Chrome and Safari extension in one. We worry about cross browser compatibility so you dont have to.
