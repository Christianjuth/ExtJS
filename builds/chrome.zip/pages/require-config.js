(function() {
  window.require = {
    baseUrl: '../../',
    paths: {
      underscore: 'bower/underscore/underscore-min',
      jquery: 'libs/jquery-min',
      ext: 'libs/ext',
      mustache: 'libs/mustache.min',
      bootstrap: 'libs/bootstrap.min',
      extPlugin: 'ext-plugins'
    },
    shim: {
      bootstrap: {
        "deps": ['jquery']
      },
      extPlugin: {
        "deps": ['ext']
      }
    }
  };

}).call(this);

//# sourceMappingURL=require-config.js.map
