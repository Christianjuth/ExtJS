/*!
Licence - 2015
--------------------------------
This plugin is protected by the MIT licence and is open source.
I ask you do not remove and/or modify this copyright in any way.
This plugin is built separately from the ExtJS framework/library
and therefor falls under its own licence (MIT).  ExtJS and other
contributors can not claim ownership.  All contributors agree their
work is open source and falls under this plugins licence (MIT).

https://github.com/Christianjuth/
 */
(function(){var a,b,c,d;d={_info:{authors:["Christian Juth"],name:"Clipboard",version:"0.5.0",min:"0.1.0",compatibility:{chrome:"full",safari:"none"}},_aliases:["clippy"],write:function(a){var b,c,d;return c=a,d=c,b=$("<input/>"),b.val(c),$("body").append(b),b.select(),document.execCommand("copy"),b.remove(),d},read:function(){var a,b,c;return a="",b="",c=$("<input/>"),$("body").append(c),c.select(),document.execCommand("paste"),b=c.val(),c.remove(),b}},c=d._info.name,a=c.toLowerCase().replace(/\ /g,"_"),b={error:function(a){return console.error("Ext plugin ("+c+") says: "+a)},warn:function(a){return console.warn("Ext plugin ("+c+") says: "+a)},info:function(a){return console.warn("Ext plugin ("+c+") says: "+a)}},"function"==typeof window.define&&window.define.amd&&window.define(["ext"],function(){return null==d._info.min||d._info.min<=window.ext.version?window.ext[a]=d:console.error("Ext plugin ("+c+") requires ExtJS v"+d._info.min+"+")})}).call(this);