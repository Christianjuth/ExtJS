(function() {
  require(["jquery", "underscore", "ext"], function($, _, ext) {
    return ext.ini();
  });

}).call(this);
